#ifndef _HELLO_WORLD_TYPES_H_
#define _HELLO_WORLD_TYPES_H_

#define HELLO_LOGGER_BOOTSTRAP_NAME "com.example.hello_logger"

typedef char *string_t;

#endif
